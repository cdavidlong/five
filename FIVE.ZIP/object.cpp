#include "object.h"

Object::Object(){
	xPos = 0; yPos = 0; zPos = 0;size = 0;
	anchored = false; visible = true;
	remove = false; selected = 0;
}

